/// @description Dash
estado = scr_player_andando;