draw_sprite(spr_personagem_sombra, 0,x,y + 16)
draw_self();
