//Movimentação
direita = -1;
cima = -1;
esquerda = -1;
baixo = -1; 

hveloc = 0;
vveloc = 0;

veloc = 1;
dir = 0;
veloc_dir = -1;

//Estado
estado = scr_player_andando;

//Dash
dash_dir = -1;
dash_veloc = 6;

//combate
max_estamina = 100;
estamina = max_estamina;
