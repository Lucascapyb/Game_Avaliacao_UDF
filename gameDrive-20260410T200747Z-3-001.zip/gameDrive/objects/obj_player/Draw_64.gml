/// @description 
draw_text(20,20,estamina);