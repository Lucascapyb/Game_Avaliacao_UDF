/// @description Inserir descrição aqui
// Você pode escrever seu código neste editor
image_angle += 1; // aumenta o ângulo da imagem a cada quadro