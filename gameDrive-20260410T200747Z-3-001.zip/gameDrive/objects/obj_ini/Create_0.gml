// Define a rotação da imagem em graus
image_angle = 45; 
