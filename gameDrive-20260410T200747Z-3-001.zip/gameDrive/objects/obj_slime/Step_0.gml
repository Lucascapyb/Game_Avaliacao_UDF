depth = -y + 10; 
script_execute(estado)