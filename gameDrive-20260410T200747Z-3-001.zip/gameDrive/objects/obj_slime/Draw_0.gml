draw_sprite(spr_slime_sombra, 0 ,x - 4 ,y + -1);
draw_self();

if dest_x < x{
	image_xscale = -1;
} else {
	image_xscale = 1;
}