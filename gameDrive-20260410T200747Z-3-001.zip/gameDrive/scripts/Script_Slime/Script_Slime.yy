{
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
  "name": "Script_Slime",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Script",
    "path": "folders/Script.yy",
  },
}