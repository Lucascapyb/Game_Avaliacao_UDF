function scr_player_colisao(){
	if place_meeting(x + hveloc, y, obj_wall){
		while !place_meeting(x + sign(hveloc), y, obj_wall){
		x += sign(hveloc);
		}
		hveloc = 0
	}

	x += hveloc;

	if place_meeting(x, y  + vveloc,  obj_wall){
		while !place_meeting(x, y + sign(vveloc), obj_wall){
		y += sign(vveloc);
		}
		vveloc = 0
	}
	y += vveloc;
}
function scr_player_andando(){
 //movimentacao + colisao
	direita = keyboard_check(ord("D"));
	esquerda = keyboard_check(ord("A"));
	cima = keyboard_check(ord("W"));
	baixo = keyboard_check(ord("S"));

	hveloc = (direita - esquerda);
	vveloc = (baixo - cima);
	
	veloc_dir = point_direction(x, y, x + hveloc, y + vveloc);
	
	if hveloc != 0 or vveloc != 0 {
		veloc = 2
	} else {
		veloc = 0
	}
	
	hveloc = lengthdir_x(veloc, veloc_dir);
	vveloc = lengthdir_y(veloc, veloc_dir);

	scr_player_colisao();
	
	 //animação
	//mudar sprite
	dir = floor(point_direction(x, y,mouse_x, mouse_y)/90);

	//mudar sprites
	dir = floor ((point_direction(x,y, mouse_x,mouse_y) + 45)/90);

	if hveloc == 0 and vveloc== 0{
	switch dir{
		default:
			sprite_index = spr_para_dir
		break; 
		case 1 : 
			sprite_index = spr_para_cost
		break;
	
		case 2 : 
			sprite_index = spr_para_esq
		break;
	
		case 3 : 
			sprite_index = spr_para_fre
		break;
		}

	} else {
		switch dir{
		default:
			sprite_index = and_dir
		break; 
		case 1 : 
			sprite_index = and_sub
		break;
	
		case 2 : 
			sprite_index = and_esq
		break;
	
		case 3 : 
			sprite_index = and_decs 
		break;
		}
	}
	
	
	if estamina>= 10{
	if keyboard_check_pressed(vk_space){
		estamina -= 15;
		alarm[1] = 200;
		
		alarm[0] = 8;
		dash_dir = point_direction(x,y, mouse_x,mouse_y);
	estado = src_personagem_dash;
		}
	}
}

function src_personagem_dash(){
	hveloc = lengthdir_x(dash_veloc, dash_dir);
	vveloc = lengthdir_y(dash_veloc, dash_dir);
	
	scr_player_colisao();
	
	var _inst = instance_create_layer(x, y, "instances", obj_dash);
	_inst.sprite_index = sprite_index;
	
}